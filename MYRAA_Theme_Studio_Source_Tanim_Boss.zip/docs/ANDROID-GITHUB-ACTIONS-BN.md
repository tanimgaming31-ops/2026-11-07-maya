# MYRAA Android: GitHub Actions + শুধু Android ফোন

**মালিকানা প্রদর্শন:** Original Creator: Tanim Boss।

## প্রয়োজন
- নিজস্ব GitHub রিপোজিটরি (Private রাখলে সাধারণ লোকেরা সোর্স দেখতে পারবে না)।
- এই ZIP-এর **ভেতরের সব ফাইল** রিপোজিটরির root-এ আপলোড করতে হবে; ZIP-কে একক ফাইল হিসেবে আপলোড করলে Actions source পাবে না।
- Android ফোনে Chrome / GitHub ও একটি unzip/git ক্লায়েন্ট।
- Gemini API Key কেবল ইনস্টল করা অ্যাপের Settings-এ দিতে হবে, GitHub repo-তে বা Actions logs-এ নয়।

## APK বিল্ড ও ডাউনলোড
1. তোমার MYRAA রিপোজিটরির Code অংশে সমস্ত সোর্স ফাইল আপলোড / push করো।
2. `.github/workflows/myraa-android-apk.yml` ফাইলটি root-এর নিচে থাকতে হবে।
3. GitHub-এর ওই রিপোজিটরি খুলে **Actions** → **MYRAA Android APK (private testing)** → **Run workflow** → **Run workflow** চাপো।
4. Run-টি সফল (সবুজ) হলে তার নিচে **Artifacts** → **MYRAA-Android-APK** চাপলে ZIP ডাউনলোড হবে।
5. ZIP Extract করে ভিতরের APK-তে চাপ দিয়ে ফোনে ইনস্টল করো। প্রয়োজনে Android-এর *Install unknown apps* অনুমতি দাও।
6. অ্যাপে **Settings** → **Contact owner on WhatsApp** চাপলে নম্বরের চ্যাট খুলবে।

## বাস্তব সীমাবদ্ধতা ও সতর্কতা
- এই source export-এ Evelyn 3D model-এর licensed asset ফাইলগুলো নেই। এ অবস্থায় GitHub Actions মডেল ছাড়া build করবে এবং অ্যাপে '3D character not bundled' দেখাবে। বাকি ফিচার কোড রয়ে যাবে। 3D-সহ নতুন APK পেতে সংশ্লিষ্ট মডেল ব্যবহারের/বণ্টনের অধিকার এবং ব্যক্তিগত build-এ asset যোগ করতে হবে।
- এই workflow-এ প্রতি নতুন run-এ নতুন development signing key তৈরি হতে পারে। ফলে পুরোনো APK-র উপর install/update ব্যর্থ হতে পারে। পুরোনো অ্যাপ uninstall করলে তার **স্থানীয় history/API settings মুছে যেতে পারে**। ভবিষ্যৎ স্থিতিশীল আপডেটের জন্য নিরাপদ স্থায়ী signing key setup আবশ্যক।
- এই GitHub Actions workflow এখানে লেখা এবং ফাইলের গঠন পরীক্ষা করা হয়েছে; GitHub runner-এ সত্যিকারের compile/install পরীক্ষা হয়নি। Build fail হলে error log দেখে ঠিক করতে হবে।
- GitHub repository Private রাখলে অন্যরা কোড দেখতে পাবে না। WhatsApp button কোনো copy protection বা access-control system নয়। আগে MIT-লাইসেন্সে দেওয়া কোডে পূর্বের লাইসেন্স-অধিকার বহাল থাকবে।
- Source export আর পূর্বে দেওয়া RC5 Android APK এক জিনিস নয়; পুরোনো APK-তে নতুন WhatsApp button যোগ হয়নি। নতুন button পাওয়া যাবে কেবল workflow-তে এই পরিবর্তিত সোর্স থেকে নতুন APK সফলভাবে build হলে।
- APK-তে আসল Gemini API response, WhatsApp contact flow, background voice এবং 3D character সফলভাবে ফোনে পরীক্ষা না করলে কাজ করছে বলে ধরে নিও না।
