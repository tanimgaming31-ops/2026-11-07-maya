import test from 'node:test';
import assert from 'node:assert/strict';
import { THEMES, SCENES, readVisualSettings, parseVisualCommand } from '../src/mobile/themeStudio';

test('catalog has distinct themes and scenes', () => {
  assert.equal(THEMES.length, 8);
  assert.equal(new Set(THEMES.map(t => t.id)).size, THEMES.length);
  assert.equal(new Set(SCENES.map(s => s.id)).size, SCENES.length);
  for (const t of THEMES) assert.ok(SCENES.find(s => s.id === t.scene));
});
test('settings load safely from corrupt or hostile storage', () => {
  assert.equal(readVisualSettings({ getItem: () => 'not json' }).theme,'crimson');
  assert.deepEqual(readVisualSettings({ getItem: () => '{"theme":"invalid","mode":"what","scene":"bad","motion":false}' }), {theme:'crimson',mode:'orb',scene:'orbit',motion:false});
  assert.equal(readVisualSettings({ getItem: () => '{"theme":"rose","scene":"garden","mode":"character"}' }).mode, 'character');
});
const cases: Array<[string,string,string?]> = [
  ['MYRAA, change the background to blue','theme','electric'],
  ['মায়রা ব্যাকগ্রাউন্ড লাল করে দাও','theme','crimson'],
  ['মায়রা ব্যাকগ্রাউন্ড চেঞ্জ করো','next'],
  ['मायरा बैकग्राउंड गुलाबी कर दो','theme','rose'],
  ['Ganti warna hijau','theme','emerald'],
  ['Palitan ang kulay ng purple','theme','violet'],
  ['Change to gold theme','theme','golden'],
  ['MYRAA change character to anime girl','mode','character'],
  ['MYRAA switch to orb mode','mode','orb'],
  ['Change background to moonlight','scene','moonlight'],
  ['Change theme to neon magenta','theme','magenta'],
  ['Change sky blue background','theme','sky'],
  ['Pulse the orb','pulse'],
];
for(const [utterance, action, value] of cases) test(`voice command ${utterance}`,()=> {
  const result=parseVisualCommand(utterance);
  assert.equal(result?.action,action);
  if(value)assert.equal(result?.value,value);
});
test('unrelated text does not change the theme',()=> {
  assert.equal(parseVisualCommand('I saw a blue car today.'),null);
  assert.equal(parseVisualCommand('Hello, how are you?'),null);
});
