/**
 * MYRAA Theme Studio: self-contained themes, interaction and particle orb.
 * No private 3D models, external services or API keys are required.
 * Theme choices are stored on this device only.
 */
export const THEMES = [
  { id: 'crimson', label: 'Crimson Red', accent: '#ff375e', rgb: [255, 55, 94], scene: 'orbit' },
  { id: 'rose', label: 'Rose Pink', accent: '#ff65ba', rgb: [255, 101, 186], scene: 'garden' },
  { id: 'violet', label: 'Violet Purple', accent: '#b57aff', rgb: [181, 122, 255], scene: 'nebula' },
  { id: 'electric', label: 'Electric Blue', accent: '#39b9ff', rgb: [57, 185, 255], scene: 'cyber' },
  { id: 'emerald', label: 'Emerald Green', accent: '#36e8ad', rgb: [54, 232, 173], scene: 'lounge' },
  { id: 'golden', label: 'Golden Sun', accent: '#ffc76d', rgb: [255, 199, 109], scene: 'sunset' },
  { id: 'sky', label: 'Sky Blue', accent: '#88dcff', rgb: [136, 220, 255], scene: 'sky' },
  { id: 'magenta', label: 'Neon Magenta', accent: '#ff59e6', rgb: [255, 89, 230], scene: 'neo-city' },
] as const;
export type ThemeId = (typeof THEMES)[number]['id'];
export type AvatarMode = 'orb' | 'character';
export type SceneId = 'orbit' | 'garden' | 'nebula' | 'cyber' | 'lounge' | 'sunset' | 'sky' | 'neo-city' | 'moonlight';
export const SCENES: ReadonlyArray<{ id: SceneId; label: string; subtitle: string }> = [
  { id: 'orbit', label: 'Particle Orbit', subtitle: 'Dark cinematic glow' },
  { id: 'garden', label: 'Rose Garden', subtitle: 'Soft pink ambience' },
  { id: 'nebula', label: 'Purple Nebula', subtitle: 'Violet space mist' },
  { id: 'cyber', label: 'Cyber Studio', subtitle: 'Blue holographic light' },
  { id: 'lounge', label: 'Emerald Lounge', subtitle: 'Mint glass & leaves' },
  { id: 'sunset', label: 'Golden Horizon', subtitle: 'Warm golden light' },
  { id: 'sky', label: 'Azure Sky', subtitle: 'Fresh open blue' },
  { id: 'neo-city', label: 'Neon Night', subtitle: 'Pink futuristic city' },
  { id: 'moonlight', label: 'Moonlight', subtitle: 'Indigo silver glow' },
];
// These are *concept screenshot previews*; they are not actual 3D rigs or implemented costumes.
export const DESIGN_PREVIEWS = [
  { name: 'Original character UI', image: 'neon-character.jpg' },
  { name: 'Original red orb', image: 'red-orb.jpg' },
  { name: 'Premium orb screen', image: 'red-orb-ui.jpg' },
  { name: 'Mint character studio', image: 'mint-character.jpg' },
  { name: 'Lavender character studio', image: 'lavender-character.jpg' },
  { name: 'Rose character studio', image: 'rose-character.jpg' },
  { name: 'Blue sky studio', image: 'sky-character.jpg' },
  { name: 'Cyber hologram studio', image: 'cyber-character.jpg' },
  { name: 'Magenta character studio', image: 'magenta-character.jpg' },
  { name: 'Green lounge studio', image: 'green-character.jpg' },
  { name: 'Cinematic neon studio', image: 'cinematic-character.jpg' },
  { name: 'Pink dressing studio', image: 'pink-character.jpg' },
  { name: 'Electric blue UI', image: 'blue-character.jpg' },
  { name: 'Rose fantasy scene', image: 'fantasy-character.jpg' },
] as const;
export type VisualSettings = { theme: ThemeId; mode: AvatarMode; scene: SceneId; motion: boolean };
const STORE_KEY = 'myraa.visual.studio.v1';
const DEFAULTS: VisualSettings = { theme: 'crimson', mode: 'orb', scene: 'orbit', motion: true };
function availableTheme(value: unknown): value is ThemeId { return THEMES.some(t => t.id === value); }
function availableScene(value: unknown): value is SceneId { return SCENES.some(s => s.id === value); }
export function readVisualSettings(storage: Pick<Storage, 'getItem'> | undefined = typeof localStorage !== 'undefined' ? localStorage : undefined): VisualSettings {
  try {
    const parsed = JSON.parse(storage?.getItem(STORE_KEY) || '{}');
    return { theme: availableTheme(parsed.theme) ? parsed.theme : DEFAULTS.theme,
      mode: parsed.mode === 'character' ? 'character' : 'orb', scene: availableScene(parsed.scene) ? parsed.scene : DEFAULTS.scene,
      motion: parsed.motion !== false };
  } catch { return { ...DEFAULTS }; }
}
export function parseVisualCommand(raw: string): { action: 'theme' | 'mode' | 'scene' | 'next' | 'pulse'; value?: string } | null {
  const text = raw.toLocaleLowerCase().normalize('NFKC').trim();
  if (text.length < 3 || text.length > 900) return null;
  const isCommand = /(?:change|switch|set|make|turn|show|use|cycle|next|background|theme|colour|color|scene|avatar|character|mode|orb|particle|rotate|pulse|switch to|নাও|চেঞ্জ|বদল|বদলে|পাল্টা|পরিবর্তন|রঙ|কালার|ব্যাকগ্রাউন্ড|থিম|গোল|অরব|চরিত্র|बदल|रंग|थीम|बैकग्राउंड|बदलो|बदलें|पृष्ठभूमि|ubah|ganti|warna|latar|tema|palitan|palit|kulay|likuran|baguhin|cambiar|cambia|color|fondo|modifica|changer|couleur|hintergrund|変更|変えて|색상|배경|色|背景|لون|غيّر|غير|تغيير|پس منظر|تبدیل)/iu.test(text);
  if (!isCommand) return null;
  const colors: Array<[ThemeId, RegExp]> = [
    ['crimson', /\b(?:red|crimson|ruby|rojo|rouge|rot|merah|pula)\b|লাল|लाल|赤|빨강|أحمر|سرخ/iu],
    ['rose', /\b(?:pink|rose|rosado|rosa|rosé|rosy|kulay rosas)\b|গোলাপি|गुलाबी|핑크|ピンク|وردي|گلابی/iu],
    ['violet', /\b(?:purple|violet|lavender|ungu|lila|lilac)\b|বেগুনি|बैंगनी|紫|보라|بنفسجي/iu],
    ['sky', /\b(?:sky|sky blue|light blue|azure|cyan|aqua|langit|langit biru)\b|আকাশি|आसमानी|하늘색/iu],
    ['electric', /\b(?:blue|electric blue|azul|bleu|blau|biru|asul)\b|নীল|नीला|青|파랑|أزرق|نیلا/iu],
    ['emerald', /\b(?:green|emerald|teal|mint|verde|vert|grün|hijau|berde)\b|সবুজ|हरा|緑|초록|أخضر|سبز/iu],
    ['golden', /\b(?:gold|golden|yellow|amber|ginto|dilaw|kuning|emas|amarillo|jaune)\b|সোনালি|হলুদ|पीला|सुनहरा|金色|노랑|ذهبي|سنہری/iu],
    ['magenta', /\b(?:magenta|neon pink|fuchsia|neon purple)\b|ম্যাজেন্টা|मैजेंटा/iu],
  ];
  for (const [id, pattern] of colors) if (pattern.test(text)) return { action: 'theme', value: id };
  if (/\b(?:pulse|beat|throb|react)\b|স্পন্দন|পালস|धड़क|स्पंदन/iu.test(text)) return { action: 'pulse' };
  if (/\b(?:orb|particles?|sphere|ball)\b|অরব|কণা|গোল|गेंद|球|オーブ|구체|الجسيمات/u.test(text) && /\b(?:show|use|switch|change|mode|make|set|orb)\b|দেখা|চেঞ্জ|পরিবর্তন|বদল|देख|ubah|ganti|palit/iu.test(text)) return { action: 'mode', value: 'orb' };
  if (/\b(?:anime|girl|3d character|character|avatar|model|human|person|female)\b|মেয়ে|চরিত্র|এনিমে|किरदार|लड़की|करैक्टर|アバター|캐릭터/iu.test(text)) return { action: 'mode', value: 'character' };
  const scenes: Array<[SceneId, RegExp]> = [
    ['moonlight', /moon|lunar|চাঁদ|চন্দ্র|bulan|月|चाँद/i],
    ['garden', /garden|flower|rose garden|ফুল|বাগান|taman|花|बगीचा/i],
    ['cyber', /cyber|hologram|futuristic|সাইবার|सायबर|未来/i],
    ['lounge', /lounge|nature|mint room|রুম|প্রকৃতি|ruang|लाउंज/i],
    ['sunset', /sunset|beach|সূর্যাস্ত|সৈকত|pantai|सूर्यास्त/i],
    ['sky', /sky|cloud|আকাশ|মেঘ|langit|आसमान/i],
    ['neo-city', /city|neon night|শহর|kota|शहर/i],
    ['nebula', /nebula|galaxy|গ্যালাক্সি|लौकिक|星雲/i],
    ['orbit', /orbit|particle background|অরব ব্যাকগ্রাউন্ড|कण/i],
  ];
  for (const [id, pattern] of scenes) if (pattern.test(text)) return { action: 'scene', value: id };
  if (/\b(?:background|theme|color|colour|scene|next|cycle|change)\b|ব্যাকগ্রাউন্ড|থিম|কালার|রঙ|বদল|পরিবর্তন|बैकग्राउंड|थीम|पृष्ठभूमि|बदलो|बदलें|लतर|latar|tema|palitan|kulay|likuran|cambiar|fondo|背景|색상|배경|لون|غيّر|غير|پس منظر/iu.test(text)) return { action: 'next' };
  return null;
}

const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x));
const rnd = (n: number) => { const a = Math.sin(n * 127.1 + n * n * 0.0091) * 43758.5453123; return a - Math.floor(a); };

/** A GPU-free, animated canvas sphere. Designed to run on midrange Android phones. */
export class ParticleOrb {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private frameId = 0;
  private lastFrame = 0;
  private started = false;
  private width = 1;
  private height = 1;
  private yaw = 0;
  private pitch = -0.1;
  private offsetX = 0;
  private offsetY = 0;
  private scale = 1;
  private activity: 'idle' | 'listening' | 'speaking' | 'thinking' = 'idle';
  private color: readonly number[] = [255, 55, 94];
  private burst = 0;
  private motion = true;
  private ro: ResizeObserver | undefined;
  private handlers: Array<[string, EventListener]> = [];
  private pointer: { x: number; y: number; active: boolean; mode: 'rotate' | 'move' } | null = null;
  private pinch = 0;
  private points: Array<{x:number;y:number;z:number;r:number}> = [];
  constructor(host: HTMLElement, color: readonly number[]) {
    this.canvas = document.createElement('canvas'); this.canvas.className = 'myraa-particle-canvas'; this.canvas.setAttribute('aria-hidden', 'true');
    this.ctx = this.canvas.getContext('2d', { alpha: true })!;
    if (!this.ctx) throw new Error('This device does not support a 2D canvas.');
    host.replaceChildren(this.canvas);
    this.color = color;
    for (let i=0; i<800; i++) {
      const y = 1 - 2 * (i + 0.5) / 800;
      const rad = Math.sqrt(Math.max(0, 1 - y * y));
      const a = i * Math.PI * (3 - Math.sqrt(5));
      const jitter = 0.9 + rnd(i) * 0.15;
      this.points.push({ x: rad*Math.cos(a)*jitter, y: y*jitter, z: rad*Math.sin(a)*jitter, r: 0.6 + rnd(i+1200)*1.5 });
    }
    const pointerdown: EventListener = (e: Event) => { const p=e as PointerEvent; this.pointer = { x:p.clientX,y:p.clientY,active:true,mode: this.pointerMode }; this.canvas.setPointerCapture(p.pointerId); this.pulse(); };
    const pointermove: EventListener = (e: Event) => { const p=e as PointerEvent; if (!this.pointer?.active) return;
      const dx=p.clientX-this.pointer.x, dy=p.clientY-this.pointer.y; this.pointer.x=p.clientX; this.pointer.y=p.clientY;
      if (this.pointer.mode==='move') { this.offsetX=clamp(this.offsetX+dx,-100,100); this.offsetY=clamp(this.offsetY+dy,-140,140); }
      else { this.yaw+=dx*0.013; this.pitch=clamp(this.pitch+dy*0.008,-1.0,1.0); }
    };
    const pointerup: EventListener = () => { this.pointer = null; };
    for (const [name,cb] of [['pointerdown',pointerdown],['pointermove',pointermove],['pointerup',pointerup],['pointercancel',pointerup]] as Array<[string,EventListener]>) { this.canvas.addEventListener(name,cb); this.handlers.push([name,cb]); }
    this.ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => this.resize()) : undefined;
    this.ro?.observe(host);
    this.resize();
  }
  public pointerMode: 'rotate' | 'move' = 'rotate';
  setTheme(color: readonly number[]) { this.color = color; }
  setMotion(enabled: boolean) { this.motion = enabled; }
  setActivity(activity: 'idle' | 'listening' | 'speaking' | 'thinking') { this.activity = activity; }
  pulse() { this.burst = 1; }
  rotate() { this.yaw+=0.8; this.pulse(); }
  move() { this.offsetX = this.offsetX < 36 ? this.offsetX + 20 : -40; this.pulse(); }
  zoom(dir: number) { this.scale=clamp(this.scale+dir*0.12,0.65,1.5); }
  reset() { this.yaw=0;this.pitch=-0.1;this.offsetX=0;this.offsetY=0;this.scale=1;this.burst=1; }
  private resize() {
    const rect = this.canvas.parentElement?.getBoundingClientRect(); if (!rect) return;
    this.width=Math.max(1,rect.width); this.height=Math.max(1,rect.height);
    const ratio=Math.min(window.devicePixelRatio||1,1.5);
    this.canvas.width=Math.round(this.width*ratio); this.canvas.height=Math.round(this.height*ratio);
    this.canvas.style.width='100%';this.canvas.style.height='100%';
    this.ctx.setTransform(ratio,0,0,ratio,0,0);
  }
  start() { if (this.started) return;this.started=true;this.lastFrame=0;this.frameId=requestAnimationFrame(this.draw); }
  stop() { this.started=false;cancelAnimationFrame(this.frameId); }
  dispose() { this.stop();this.ro?.disconnect();for(const [n,f] of this.handlers) this.canvas.removeEventListener(n,f);this.canvas.remove(); }
  private draw = (now: number) => {
    if(!this.started) return;
    this.frameId = requestAnimationFrame(this.draw);
    if (now-this.lastFrame < (this.motion ? 30 : 80)) return;
    const dt=clamp(now-this.lastFrame,0,80)/1000;this.lastFrame=now;
    const ctx=this.ctx, w=this.width,h=this.height;
    ctx.clearRect(0,0,w,h);
    const radius=Math.min(w*0.35,h*0.36)*this.scale;
    const cx=w*.5+this.offsetX,cy=h*.49+this.offsetY;
    const [r,g,b]=this.color;
    const rgba=(a:number)=>`rgba(${r},${g},${b},${a})`;
    if (this.motion) this.yaw+=dt*(this.activity==='speaking'?.55:this.activity==='listening'?.30:.16);
    this.burst=Math.max(0,this.burst-dt*.75);
    const breath=this.motion?Math.sin(now*.0019)*.025:0;
    const strength=1+breath+this.burst*.09;
    const glow=ctx.createRadialGradient(cx,cy,radius*.12,cx,cy,radius*1.55);
    glow.addColorStop(0,'rgba(4,3,12,0)');glow.addColorStop(.65,rgba(.085));glow.addColorStop(.84,rgba(.12));glow.addColorStop(1,rgba(0));
    ctx.fillStyle=glow;ctx.beginPath();ctx.arc(cx,cy,radius*1.6,0,Math.PI*2);ctx.fill();
    for (let j=0;j<3;j++) {
      ctx.save();ctx.translate(cx,cy);ctx.rotate((j%2?-1:1)*now*.00007+j*.4);
      ctx.strokeStyle=rgba(j===1?.2:.38);ctx.lineWidth=j===1?1.1:2.2;
      ctx.shadowColor=rgba(.6);ctx.shadowBlur=7;
      ctx.beginPath();ctx.ellipse(0,0,radius*(1.1+j*.14),radius*(1.04+j*.12),j*.55,Math.PI*.12,Math.PI*1.69);ctx.stroke();ctx.restore();
    }
    const cyaw=Math.cos(this.yaw),syaw=Math.sin(this.yaw),cp=Math.cos(this.pitch),sp=Math.sin(this.pitch);
    ctx.save();ctx.translate(cx,cy);
    ctx.beginPath();ctx.arc(0,0,radius*.98,0,Math.PI*2);ctx.clip();
    ctx.fillStyle='rgba(3,3,12,.84)';ctx.fillRect(-radius,-radius,radius*2,radius*2);
    for (const p of this.points) {
      const x=p.x*cyaw+p.z*syaw;
      const z=-p.x*syaw+p.z*cyaw;
      const y=p.y*cp-z*sp;
      const depth=p.y*sp+z*cp;
      const perspective=1+.12*depth;
      const px=x*radius*perspective*strength,py=y*radius*perspective*strength;
      const opacity=clamp(.18+(depth+1)*.31+this.burst*.15,0,1);
      const size=p.r*(.75+.4*(1+depth))*Math.min(1.3,this.scale);
      ctx.beginPath();ctx.fillStyle=rgba(opacity);ctx.arc(px,py,size,0,Math.PI*2);ctx.fill();
    }
    ctx.restore();
    ctx.save();ctx.strokeStyle=rgba(.35);ctx.shadowBlur=13;ctx.shadowColor=rgba(.7);ctx.lineWidth=2;ctx.beginPath();ctx.arc(cx,cy,radius,0,Math.PI*2);ctx.stroke();ctx.restore();
    const base=ctx.createRadialGradient(cx,cy+radius*.98,2,cx,cy+radius*.98,radius);
    base.addColorStop(0,rgba(.3));base.addColorStop(1,rgba(0));
    ctx.fillStyle=base;ctx.fillRect(cx-radius,cy+radius*.85,radius*2,radius*.8);
  };
}

export class ThemeStudio {
  visual: VisualSettings;
  orb: ParticleOrb | null = null;
  private onModeChange: (mode: AvatarMode) => void;
  private onNotice: (message: string) => void;
  constructor(onModeChange:(mode: AvatarMode)=>void, onNotice:(message:string)=>void) {
    this.visual=readVisualSettings();this.onModeChange=onModeChange;this.onNotice=onNotice;
  }
  mount(avatar: HTMLElement) {
    this.orb?.dispose();this.orb=new ParticleOrb(avatar, THEMES.find(t=>t.id===this.visual.theme)!.rgb);
    this.orb.setMotion(this.visual.motion && !window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    if(!document.hidden) this.orb.start();
  }
  private save() { try{localStorage.setItem(STORE_KEY,JSON.stringify(this.visual));}catch{/* private browsing/denied storage */} }
  setTheme(id: ThemeId, sceneToo=true) {
    const theme=THEMES.find(t=>t.id===id)!;
    this.visual.theme=id;
    if(sceneToo)this.visual.scene=theme.scene;
    this.save();this.render();this.onNotice(`${theme.label} theme selected.`);
  }
  setScene(id: SceneId) {this.visual.scene=id;this.save();this.render();this.onNotice(`${SCENES.find(s=>s.id===id)?.label||id} background selected.`);}
  setMode(mode:AvatarMode) { this.visual.mode=mode;this.save();this.render();this.onModeChange(mode); }
  setMotion(motion:boolean) { this.visual.motion=motion;this.save();this.render(); }
  next() { const index=THEMES.findIndex(t=>t.id===this.visual.theme);this.setTheme(THEMES[(index+1)%THEMES.length].id); }
  execute(input:string):boolean {
    const command=parseVisualCommand(input);if(!command)return false;
    if(command.action==='theme')this.setTheme(command.value as ThemeId);
    if(command.action==='scene')this.setScene(command.value as SceneId);
    if(command.action==='mode')this.setMode(command.value as AvatarMode);
    if(command.action==='next')this.next();
    if(command.action==='pulse')this.orb?.pulse();
    return true;
  }
  render() {
    const theme=THEMES.find(t=>t.id===this.visual.theme)!;
    document.documentElement.style.setProperty('--myraa-accent',theme.accent);
    document.documentElement.style.setProperty('--myraa-rgb',theme.rgb.join(', '));
    document.body.dataset.myraaScene=this.visual.scene;
    document.body.dataset.myraaMode=this.visual.mode;
    this.orb?.setTheme(theme.rgb);
    this.orb?.setMotion(this.visual.motion && !window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    document.querySelectorAll<HTMLButtonElement>('[data-theme]').forEach(button=>{const selected=button.dataset.theme===this.visual.theme;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));});
    document.querySelectorAll<HTMLButtonElement>('[data-scene]').forEach(button=>{const selected=button.dataset.scene===this.visual.scene;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));});
    document.querySelectorAll<HTMLButtonElement>('[data-mode]').forEach(button=>{const selected=button.dataset.mode===this.visual.mode;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));});
    const label=document.getElementById('theme-active');if(label)label.textContent=`${theme.label} · ${SCENES.find(s=>s.id===this.visual.scene)?.label}`;
    const motion=document.getElementById('motion-toggle') as HTMLInputElement|null;if(motion)motion.checked=this.visual.motion;
    const modelButtons=document.querySelectorAll<HTMLElement>('.character-only');modelButtons.forEach(x=>x.hidden=this.visual.mode!=='character');
    const orbButtons=document.querySelectorAll<HTMLElement>('.orb-only');orbButtons.forEach(x=>x.hidden=this.visual.mode!=='orb');
  }
  bindControls() {
    const palette=document.getElementById('theme-palette');
    if(palette)palette.innerHTML=THEMES.map(t=>`<button type="button" data-theme="${t.id}" class="theme-swatch" title="${t.label}" style="--swatch:${t.accent}"><span class="swatch-dot"></span><small>${t.label}</small></button>`).join('');
    const scenes=document.getElementById('scene-palette');
    if(scenes)scenes.innerHTML=SCENES.map(s=>`<button type="button" data-scene="${s.id}" class="scene-tile"><span class="scene-thumb scene-${s.id}"></span><strong>${s.label}</strong><small>${s.subtitle}</small></button>`).join('');
    const previews=document.getElementById('concept-gallery');
    if(previews)previews.innerHTML=DESIGN_PREVIEWS.map(p=>`<button type="button" class="concept-item" data-preview="${p.image}"><img loading="lazy" src="./design-previews/${p.image}" alt="${p.name}" /><small>${p.name}</small></button>`).join('');
    document.querySelectorAll<HTMLButtonElement>('[data-theme]').forEach(b=>b.onclick=()=>this.setTheme(b.dataset.theme as ThemeId));
    document.querySelectorAll<HTMLButtonElement>('[data-scene]').forEach(b=>b.onclick=()=>this.setScene(b.dataset.scene as SceneId));
    document.querySelectorAll<HTMLButtonElement>('[data-mode]').forEach(b=>b.onclick=()=>this.setMode(b.dataset.mode as AvatarMode));
    const get=(id:string)=>document.getElementById(id);
    get('theme-next')?.addEventListener('click',()=>this.next());
    get('theme-open')?.addEventListener('click',()=>{(get('theme-panel') as HTMLDialogElement).showModal();this.render();});
    get('theme-close')?.addEventListener('click',()=>{(get('theme-panel') as HTMLDialogElement).close();});
    get('motion-toggle')?.addEventListener('change',e=>this.setMotion((e.target as HTMLInputElement).checked));
    get('orb-rotate')?.addEventListener('click',()=>this.orb?.rotate());
    get('orb-move')?.addEventListener('click',()=>{if(this.orb){this.orb.pointerMode=this.orb.pointerMode==='rotate'?'move':'rotate';this.orb.move();this.onNotice(`Swipe to ${this.orb.pointerMode}.`);}});
    get('orb-pulse')?.addEventListener('click',()=>this.orb?.pulse());
    get('orb-zoom-in')?.addEventListener('click',()=>this.orb?.zoom(1));
    get('orb-zoom-out')?.addEventListener('click',()=>this.orb?.zoom(-1));
    get('orb-reset')?.addEventListener('click',()=>this.orb?.reset());
    get('concept-gallery')?.addEventListener('click',e=>{
      const btn=(e.target as HTMLElement).closest<HTMLElement>('[data-preview]');if(!btn)return;
      const file=btn.dataset.preview;
      const viewer=get('concept-preview') as HTMLDialogElement;
      const img=viewer?.querySelector('img');if(img&&file)img.src=`./design-previews/${file}`;
      const title=viewer?.querySelector('figcaption');if(title)title.textContent=DESIGN_PREVIEWS.find(p=>p.image===file)?.name||'Design preview';
      viewer?.showModal();
    });
    get('concept-close')?.addEventListener('click',()=>{(get('concept-preview') as HTMLDialogElement).close();});
    this.render();
  }
}
