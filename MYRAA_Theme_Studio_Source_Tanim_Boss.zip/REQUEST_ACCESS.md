# MYRAA AI Assistant — Private Access Request

**Application:** MYRAA AI Assistant  
**Original Creator:** Tanim Boss  
**Sole Owner of Independently Created Original Contributions:** Tanim Boss

## Request permission via WhatsApp

The repository owner must approve access to **private project materials** before granting a GitHub invitation or sharing a private download. No GitHub clone, fork, or download action can be automatically redirected to WhatsApp by a README or licence file.

**Contact status: CONFIGURED (tap the number).** Requests go to Tanim Boss on WhatsApp. This number is embedded in this file and in the public request page, so it will be visible to readers.

[+971 55 512 4483](https://wa.me/971555124483?text=Hello%20Tanim%20Boss%2C%20I%20would%20like%20to%20request%20permission%20to%20access%20the%20private%20MYRAA%20AI%20Assistant%20source%20code.%20My%20name%3A%20%5Bname%5D.%20GitHub%20username%3A%20%5Busername%5D.%20Intended%20use%3A%20%5Bpurpose%5D.)

Tap the displayed **+971 55 512 4483** number to open the WhatsApp chat with a prefilled message. The applicant must press **Send**. A request does not grant access automatically.

For a public contact page, host the configured `request-access.html` separately, for example on a public GitHub Pages site. Keep the actual MYRAA source repository **private**.

### Authorization process

1. Applicant opens the WhatsApp request link and sends the message.
2. Tanim Boss reviews the applicant, use case, and applicable intellectual-property rights.
3. If approved, Tanim Boss invites the applicant through the **private GitHub repository's access controls** or shares only specifically authorized materials.
4. If not approved, no private source access is granted.
5. Access to a private repository is not an automatic licence to redistribute any separately proprietary code or assets.

### Important rights and limitations

- Existing MYRAA application source is accompanied by an **MIT licence**. Permissions already granted under that licence remain valid. This request process does **not** revoke MIT permissions.
- Third-party software and character assets retain their own licences, and the included Evelyn model has limitations described in `THIRD-PARTY-NOTICES.md`.
- Separate, newly developed proprietary material not covered by MIT or another licence requires permission from its lawful owner before use or sharing.
- Do not place private Android APKs, models, secrets, API keys, or private code in the public request page repository.
- If an approved recipient receives a local copy, changing repository visibility cannot remotely erase that copy.

**No claim of exclusive ownership of third-party works is made by this notice.**
